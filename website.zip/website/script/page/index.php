<?php view::header(); ?>

<style>
    .pagefault {
        background: rgba(255, 255, 255, 0.5);
        border: 1px solid gainsboro;
        padding: 10px;
        border-radius: 3px;
        font-family: "STFS";
        font-size: 18px;
    }

    #welcometxt {
        text-align: center;
    }
</style>

<body>
    <div class="container">
        <?php
        echosi(); ?>
        <div style="text-align: center;font-size:95px;font-family:'STFS'" id="time"></div>
        <h1 id="sdate"></h1>
        <?= DB::getdata('sys/mainpagetext') ?>
    </div>
</body>

<?php view::foot(); ?>
<script>
    function gettime() {
        var nowtime = new Date();
        var hours = nowtime.getHours().toString().padStart(2, "0");
        var minutes = nowtime.getMinutes().toString().padStart(2, "0");
        var seconds = nowtime.getSeconds().toString().padStart(2, "0");
        var milliseconds = nowtime.getMilliseconds().toString().padStart(3, "0");
        document.getElementById("time").innerHTML = hours + ":" + minutes + ":" + seconds //+ "<span class='ms'>." + milliseconds+"</span>";
        
        var targetDate = new Date(2024, 6, 21); // 注意月份是从0开始的，所以6代表7月  
        targetDate.setHours(0, 0, 0, 0); // 确保时间是午夜  
        // 获取当前日期和时间  
        var now = new Date();
        // 计算时间差（毫秒）  
        var diff = now - targetDate;
        // 将时间差转换为天、小时、分钟和秒  
        var dayint=Math.floor(diff / (1000 * 60 * 60 * 24))
        var days = (dayint+1)%31;
        var months = (Math.floor(dayint / 31)+1)%12;
        var years = Math.floor(dayint / 372)+1;
        document.getElementById("sdate").innerHTML = "痴历"+ years+"年"+months+"月" + days + "日";
    }
    gettime()
    sh = setInterval(function() {
        gettime()
    }, 1000);
</script>
<style>
    h1 {
        font-weight: 300;
    }

    .clock {
        position: absolute;
        height: 100px;
        line-height: 100px;
        top: calc(50% - 60px);
        text-align: center;
        width: 100%;
        font-weight: 300;
    }

    #sdate {
        text-align: center;
        width: 100%;
        font-weight: 500;
        font-size: 35px;
    }
</style>