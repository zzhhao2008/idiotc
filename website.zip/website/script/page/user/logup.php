<?php
function emptycheck(){
    return empty($_POST['nickname'])||empty($_POST['id'])||empty($_POST['password']);
}
$alert="";
if ($_POST['id']) {
    $id = $_POST['id'];
    if (user::queryUser($id)) {
        $alert="该用户名已被使用";
    }elseif(emptycheck()){
        $alert="请不要空项";
    }
    else {
        $thiscfg = $emptycfg;
        $thiscfg['nick'] = $_POST['nickname'];
        $thiscfg['name'] = $_POST['username'];
        $passwrd=$_POST['password'];
        $thiscfg['password'] = md5($passwrd);
        DB::putdata("user/$id", $thiscfg);
        echo user::login($id,$passwrd);
        jsjump("/profile");
    }
    view::alert($alert,"warning");
}
?>
<?php view::header("注册"); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <form method="post">
                    <div class="mb-3">
                        <img src="/icon.jpg" style="height: 100px;border-radius:5px">
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">昵称</label>
                        <input type="text" class="form-control" id="nickname" name="nickname" aria-describedby="usernameHelp">
                        <div id="usernameHelp" class="form-text">请输入昵称</div>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">账号</label>
                        <input type="text" class="form-control" id="email" name="id" aria-describedby="usernameHelp">
                        <div id="usernameHelp" class="form-text">请输入账号</div>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">密码</label>
                        <input type="password" class="form-control" id="password" name="password" aria-describedby="passwordHelp">
                        <div id="passwordHelp" class="form-text">请输入密码</div>
                    </div>
                    <div class="mb-3">
                        <?=$alert?>
                    </div>
                    <button type="submit" class="btn btn-primary">注册</button>
                    <a type="button" href="/profile" class="btn btn-default">登录</a>
                </form>
            </div>

        </div>
    </div>
</div>
<?php view::foot(); ?>