<?php
    $chiname="中书省行政文书发布";
    view::header("$chiname");
    $text=DB::getdata("province/cha");
    if(isset($_POST['face'])){
        $text=$_POST['face'];
        DB::putdata("province/cha",$text);
    }
?>
<div class="container abox">
    <h3><?=$chiname?></h3>
    <hr>
    <?=$text?>
    <hr>
    <?php
        $pos=person::queryPerson(user::read()['name'])['pos'];
        if(in_array($pos,["丞相","宰相","右丞相"])||user::is_superuser()){
            echo "<hr><h3>编辑</h3><form method='post'>";
            view::aceeditor($text,"html",0,"face");
            echo "<input value='保存' type='submit' class='btn btn-danger'></form>";
        }
    ?>
</div>
<?php view::foot() ?>