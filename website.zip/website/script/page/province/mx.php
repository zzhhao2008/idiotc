<?php
    $chiname="门下省";
    view::header("$chiname");
    $text=DB::getdata("province/mx");
    if(isset($_POST['face'])){
        $text=$_POST['face'];
        DB::putdata("province/mx",$text);
    }
?>
<div class="container abox">
    <h3><?=$chiname?></h3>
    <hr>
    <?=$text?>
    <hr>
    <?php
        $pos=person::queryPerson(user::read()['name'])['pos'];
        if(in_array($pos,["丞相","宰相","右丞相","太监","大太监"])||user::is_superuser()){
            echo "<hr><h3>编辑</h3><form method='post'>";
            view::aceeditor($text,"html",0,"face");
            echo "<input value='保存' type='submit' class='btn btn-danger'></form>";
        }
    ?>
</div>
<?php view::foot() ?>