<?php view::header("百科-")?>
<div class="container abox">
    <h2>大痴国百科体系</h2>
    <hr>
    <ul>
        <li><a href="/static/wiki.html">大痴国基本百科</a></li>
        <li><a href="/person/info">大痴国官员任职与国民基本情况</a></li>
    </ul>
</div>
<?php view::foot()?>