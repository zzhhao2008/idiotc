<?php
view::header("六部门户-");
?>
<div class="container abox">
    <h3>尚书省-六部门户网站索引</h3>
    <ul>
        <li><a href="/revenue">户部</a></li>
        <li><a href="/affair">兵部</a></li>
        <li><a href="/penalty">刑部</a></li>
        <li><a href="/rites">礼部</a></li>
        <li><a href="/work">工部</a></li>
        <li><a href="/person/index">吏部</a></li>
    </ul>
</div>
<?php view::foot() ?>