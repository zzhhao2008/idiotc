<?php
    $chiname="工部";
    view::header("$chiname-尚书省-");
    $text=DB::getdata("ministrypages/$chiname");
    if(isset($_POST['face'])){
        $text=$_POST['face'];
        DB::putdata("ministrypages/$chiname",$text);
    }
?>
<div class="container abox">
    <h3><?=$chiname?>-尚书省</h3>
    <hr>
    <?=$text?>
    <hr>
    <?php
        $pos=person::queryPerson(user::read()['name'])['pos'];
        if($pos===$chiname."尚书"||user::is_superuser()){
            echo "<hr><h3>编辑</h3><form method='post'>";
            view::aceeditor($text,"html",0,"face");
            echo "<input value='保存' type='submit' class='btn btn-danger'></form>";
        }
    ?>
</div>
<?php view::foot() ?>