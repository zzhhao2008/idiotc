<?php view::header("国民详情-吏部-"); ?>
<div class="container abox">
    <div class="row">
        <h1>吏部</h1>
        <hr>
        <?php
        $sts = person::getStatus();
        foreach ($sts as $k => $v) {
            $id=$v['id'];
            $bdlink="";
            $uid=$v['uid'];
            if(user::queryUserAdmin($uid) && $uid){
                $bdlink="<a href='/user/vis?uid={$uid}' class='btn btn-primary'>个人空间</a>";
                $info= user::queryUserAdmin($uid)['about']??"TA是一个神秘的人";
            }else{
                $bdlink="<a href='#' class='btn btn-danger'>未绑定账号</a>";
                $info="TA是一个神秘的人";
            }
            
            echo <<<HTML
                <div class="card col-md-4">
            <img class="card-img-top" src="/static/head/{$id}.jpg" alt="Card image" style="width:100%">
            <div class="card-body">
                <h4 class="card-title">{$v['name']}</h4>
                <p class="card-text">{$v['pos']}</p>
                <p class="card-text">{$info}</p>
                {$bdlink}
            </div>
        </div>
HTML;
        }
        ?>

    </div>
</div>
<?php view::foot() ?>