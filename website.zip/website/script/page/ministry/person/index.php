<?php view::header("吏部-");?>
<div class="container abox">
    <h3>尚书省-吏部门户网站索引</h3>
    <ul>
        <li><a href="/person/info">人力资源部</a></li>
        <li><a href="/person/index">本部</a></li>
    </ul>
    <img src="/static/passages/pub1.jpg">
    <img src="/static/passages/cat4.png">
</div>
<?php view::foot() ?>