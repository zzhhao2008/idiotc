<?php
view::header("奏折批复");
$list = report::list();
$pos = person::queryPerson(user::read()['name'])['pos'];
if (empty($pos)) {
    die("请等候管理员为您绑定账号！");
}
if ($_GET['did']) {
    $die = 0;
    $data = report::get($_GET['did']);
    if ($_GET['did'] === 'new' && $pos != "皇帝") {
        $data = report::get('demo');
        $data['genid'] = "";
        $data['name'] = "大痴国奏折来自" . $pos;
        $data['author'] = user::read()['name'];
        $data['reply'] = "";
        $id = report::publish_edit($data);
        jsjump("?did=$id");
        die();
    } else if (empty($data)) {
        view::alert("该奏折不存在", "danger");
        $data = report::get('demo');
        $die = 1;
    }
    $aut = $data['author'] === user::read()['name'] ? 1 : 0;
    if ($data['pri'] && !$aut && !user::is_superuser()) {
        view::alert("该奏折为私密", "danger");
        jsjump("?");
        die();
    }
    if (!$die && ($aut || $pos === '皇帝')) {
        if ($_POST['texts']) {
            $data['text'] = $_POST['texts'];
            $data['pri'] = $_POST['private'] ? 1 : 0;
            report::publish_edit($data);
        }
        if ($_POST['reply'] && $pos === '皇帝') {
            $data['reply'] = $_POST['reply'];
            $data['stu'] = $_POST['allow'] ? 1 : 2;
            report::publish_edit($data);
        }
    }
} else {
    $data = [];
    foreach ($list as $v) {
        $data[$v] = report::get($v);
    }
    foreach ($data as $id => $d) {
        $aut = $d['author'] === user::read()['name'] ? 1 : 0;
        if ($data['pri'] && !$aut && !user::is_superuser()) continue;
        $tablebody[] = [$d['name'], user::queryUserNick($d['author'], 1, 1), getDate_ToNow($d['time']), report::status($d['stu']) . ($d['pri'] ? " <span class='text-warning'>私密</span>" : ""), "<a href='?did={$id}'>查看详情</a>"];
    }
}
?>
<div class="container abox">
    <a href="?did=new" class="btn btn-danger">新建奏折</a>
    <?php $tablebody ? view::table($tablebody, ["标题", "作者", "提交时间", "状态", "操作"]) : ""; ?>

    <?php
    if ($_GET['did']) {

        echo "<h3>奏折详情-{$data['name']}</h3>";
        echo user::queryUserNick($data['author'], 1, 1) . "于" . getDate_full($data['time']) . "提交";
        echo $aut ? "<form method='post'>" : "";
        view::aceeditor($data['text'], "text", !$aut, "texts");
        echo '<div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="mySwitch" name="private" value="1"' . ($data['pri'] ? "checked" : "") . " " . ($aut ? "" : "onclick=\"return false;\"") . '>
        <label class="form-check-label" for="mySwitch">私密</label>
    </div>';
        echo $aut ? "<input value='保存' type='submit' class='btn btn-danger'></form>" : "";
        echo "<h3>批复：</h3><pre>{$data['reply']}</pre>";
        if ($pos === '皇帝') {
            echo "<h3>奏折批复</h3>";
            echo "<form method='post'>";
            view::aceeditor($data['reply'], "text", 0, "reply");
            echo '<div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="mySwitch" name="allow" value="1" ' . ($data['stu'] === 1 ? "checked" : "") . '>
        <label class="form-check-label" for="mySwitch">通过</label>
    </div>';
            echo "<input value='保存' type='submit' class='btn btn-danger'></form>";
        }
    }
    ?>
</div>
<?php
view::foot();
?>
<style>pre {
white-space: pre-wrap;
word-wrap: break-word;
}</style>