<?php
$saying = [
    "痴痴痴痴痴痴痴痴痴痴痴痴痴痴痴痴痴"

];
$out=str_replace("\r\n","\\r\\n",$saying[rand(0, count($saying) - 1)]);
echo "\"{$out}\"";
