<?php
Router::any("/", "index");
Router::any("api/speak","api/goodspeak");
Router::any("wiki","wiki");

Router::any("person","ministry/person/info");
Router::any("person/info","ministry/person/info");
Router::any("person/index","ministry/person/index");

Router::any("revenue","ministry/revenue/index"); //户部
Router::any("affair","ministry/affair/index"); //兵部
Router::any("penalty","ministry/penalty/index"); //刑部
Router::any("ministry","ministry/index"); //部
Router::any("rites","ministry/rites/index"); //礼部
Router::any("work","ministry/work/index"); //工部

Router::any("cha","province/cha");//中书省
Router::any("mx","province/mx");//门下省

Router::guest("logup", "user/logup");
Router::guest("profile","user/login");//登录页面

Router::login("profile","user/profile");
Router::login("themeset","user/themeset");
Router::login("change","user/change");
Router::login("user/vis","user/vis");
Router::login("report","report");

Router::admin("user_manage", "admin/user/manage");
Router::admin("user_edit", "admin/user/edit");
Router::admin("user_cr_rm", "admin/user/crm");

Router::admin("mpt","/admin/sys/text");

