<?php
class report{
    static public function get($id){
        return DB::getdata("reports/$id");
    }
    static public function put($id,$data){
        return DB::putdata("reports/$id",$data);
    }
    static public function list(){
        return DB::scanName("reports/");
    }
    static public function publish_edit($data){
        $id=$data['genid'];
        if(empty($id)){
            $id=count(self::list());
            $data['genid']=$id;
        }
        self::put($id,$data);
        return $id;
    }
    static public function status($stu){
        switch ($stu){
            case 0://未处理
                return "<span class='text-primary'>未处理</span>";
                break;
            case 1://已处理
                return "<span class='text-success'>已通过</span>";
                break;
            case 2://已拒绝
                return "<span class='text-danger'>已拒绝</span>";
                break;
            default://未知
                return "<span class='text-warning'>未知</span>";
                break;
        }
    }
}