<?php
class person{
    public static function getStatus(){
        return DB::getdata("people/status");
    }
    public static function queryPerson($keytext){
        $sts=self::getStatus();
        $res=[];
        foreach( $sts as $status){
            if($status['name']==$keytext||$status['uid']===$keytext||$status['id']===$keytext){
                return $status;
            }
            if($status['pos']===$keytext){
                $res[]=$status;
            }
        }
        return $res;
    }
}